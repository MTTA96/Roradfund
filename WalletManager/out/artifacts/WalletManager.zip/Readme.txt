ver 2.0.0

*** Release note:
.Fix:


.Update:
1. Check 1 wallet / 6 secs.
2. Check token.

*** Incoming:


*** Infomation: 
1. Run WalletManager.jar
2. Can check 1 wallet/6s
